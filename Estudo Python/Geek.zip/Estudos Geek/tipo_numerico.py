"""
Tipo Numérico
"""

num = 1_000_000

print(num)

print(float(num))
